import React, { Component } from "react";
import Players from "./components/Players";
import Word from "./components/Word";
import "./App.css";

class App extends Component {
  state = {
    game: {
      type: 1,
      gameData: {
        word: "umbrella",
      },
    },
    players: [
      {
        id: 1,
        name: "Joe",
        score: "0",
        compleated: false,
      },
      {
        id: 2,
        name: "Sally",
        score: "0",
        compleated: false,
      },
      {
        id: 3,
        name: "Emma",
        score: "0",
        compleated: false,
      },
    ],
  };

  updateWord = () => {
    this.setState({
      game: { gameData: { word: "potted plant" } },
    });
  };

  updateUser = () => {
    console.log("update user");
  };

  addUser = () => {
    let player = [
      {
        id: 5,
        name: "john",
        score: 0,
        compleated: false,
      },
    ];
    this.setState({ players: [...this.state.players, player] });
  };

  render() {
    const { players, game } = this.state;
    return (
      <div className="App">
        <Players players={players} onUpdateUser={this.addUser} />
        <Word game={game} onUpdateWord={this.updateWord} />
      </div>
    );
  }
}

export default App;
