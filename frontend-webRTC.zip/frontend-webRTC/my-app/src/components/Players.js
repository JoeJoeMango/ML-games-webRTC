import React, { Component } from "react";
import Player from "./Player";

class Players extends Component {
  constructor(props) {
    super(props);
  }
  updateUser = (e) => {
    e.preventDefault();
    this.props.onUpdateUser();
  };
  render() {
    const { players } = this.props;
    return (
      <div className="container">
        <button onClick={this.updateUser}>update</button>
        {players}
        {players.map((player) => {
          return <Player key={player.id} player={player} />;
        })}
      </div>
    );
  }
}

export default Players;
