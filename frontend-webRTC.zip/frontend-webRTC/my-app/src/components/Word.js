import React, { Component } from "react";

class Word extends Component {
  constructor(props) {
    super(props);
    console.log(props);
  }

  updateWord = (e) => {
    e.preventDefault();
    this.props.onUpdateWord();
  };
  render() {
    const { type, gameData } = this.props.game;
    return (
      <div className="-bottom-">
        <div className="-game-direction">
          <button onClick={this.updateWord}>asd</button>
          {gameData.word}
        </div>
      </div>
    );
  }
}

export default Word;
